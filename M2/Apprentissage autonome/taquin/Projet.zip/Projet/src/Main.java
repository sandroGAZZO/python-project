public class Main {

	public static void main(String[] args) {
		int dim=2; //choix de dimension initiale.
		new Game(dim); // lance le jeux
	}

}

